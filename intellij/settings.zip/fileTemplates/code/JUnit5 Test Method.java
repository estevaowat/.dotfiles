@org.junit.jupiter.api.Test
@org.junit.jupiter.api.DisplayName("should ...")
void ${NAME}() {
  ${BODY}
}